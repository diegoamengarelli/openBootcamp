# Asignacion de las variables

nombre = "ALberto"
apellidos = ("Perez", "Mena")
edad = 35
email = "albertoperez@test.com"
telefono = 42526678
casado = True
con_hijos = False 
lista_de_amigos = ["Juan CAballero", "Arnaldo Montes", "Anita Juarez"]
peliculas_vistas = {
    1 : "La doncella",
    2 : "Minions",
    3 : "Thor",
}

# Imprimir las variables
print(nombre)
print(apellidos)
print(edad)
print(telefono)
print(casado)
print(con_hijos)
print(lista_de_amigos)
print(peliculas_vistas)